import React from 'react';
import './App.css'
import Api from './components/Api/Api'


function App() {
  return (
    <div className='App'>
      < Api />

    </div>
  )
}

export default App;