import React, { useState, useEffect,} from 'react';
import '../Api/Api.css'


    function App() {
    const [user, setUser] = useState([])
    
    useEffect(() => {
      fetch('https://jsonplaceholder.typicode.com/users')
      .then(response => response.json())
      .then(json => setUser(json))
    
    }, []);
    
      return <div>
          <table>
            <tr>
              <th>Id</th>
              <th>Name</th>
              <th>Username</th>
              <th>Email</th>
              <th>Address</th>
              <th>Suite</th>
              <th>Geo</th>
            </tr>
            {
              user && user.length > 0 ?
              user.map (usr => 
                <tr>
                  <td>{usr.id}</td>
                  <td>{usr.name}</td>
                  <td>{usr.username}</td>
                  <td>{usr.email}</td>
                  <td>{usr.address.street}</td>
                  <td>{usr.address.suite}</td>
                  <td>{usr.address.geo.lat}</td>
                </tr>
                )
              :"Loading"
            }
          </table>
      </div>
    }
export default App;